# General
This provider uses Strike Search API.
More informations can be found on https://getstrike.net/api/

This provider can be used ro search general content, movies or tv shows.
