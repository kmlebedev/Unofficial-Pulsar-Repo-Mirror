# coding: utf-8
import re
import subscription
from time import time
from time import asctime
from time import localtime
from time import strftime
from time import gmtime
from xbmc import log
from xbmc import sleep
from xbmc import abortRequested
from xbmcaddon import Addon


def update_service():
    # this read the settings
    settings = subscription.Settings()
    # define the browser
    browser = subscription.Browser()
    categories = {'Movies Popular': 'http://trakt.tv/movies/popular',
                  'Movies Trending': 'http://trakt.tv/movies/trending',
                  'TV Popular': 'http://trakt.tv/shows/popular',
                  'TV trending': 'http://trakt.tv/shows/trending',
                  'Watchlist': '',
                  'List': ''}
    options = categories.keys()
    options.sort()
    rets = []
    movies_popular = settings.settings.getSetting('movies_popular')
    movies_trending = settings.settings.getSetting('movies_trending')
    TV_popular = settings.settings.getSetting('TV_popular')
    TV_trending = settings.settings.getSetting('TV_trending')
    watchlist = settings.settings.getSetting('watchlist')
    sync_list = settings.settings.getSetting('sync_list')
    user = settings.settings.getSetting('user')
    password = settings.settings.getSetting('password')
    if movies_popular == 'true':
        rets.append(1)
    if movies_trending == 'true':
        rets.append(2)
    if TV_popular == 'true':
        rets.append(3)
    if TV_trending == 'true':
        rets.append(4)
    if watchlist == 'true' and user is not '':
        rets.append(5)
    if sync_list == 'true' and user is not '' and password is not '':
        rets.append(0)
    # start checking
    lists = ''
    for ret in rets:
        if ret == 5:  # watchlist
            categories[options[ret]] = 'http://trakt.tv/users/%s/watchlist' % user.lower()
        if ret == 0:  # List
            browser.open('http://trakt.tv/auth/signin')
            token = re.search('name="authenticity_token" value="(.*?)"', browser.content).group(1)
            browser.login('http://trakt.tv/auth/signin', {'utf8': '&#x2713;', 'user[login]': user,
                                                          'user[password]': password, 'commit': 'Sign in',
                                                          'user[remember_me]': 1,
                                                          'authenticity_token': token})
            categories[options[ret]] = 'http://trakt.tv/users/%s/lists/' % user.lower()
            browser.open(categories[options[ret]])
            lists = list(set(re.findall('/lists/(.*?)"', browser.content)))
        url_search = categories[options[ret]]  # define url
        settings.log('[%s]%s' % (settings.name_provider_clean, url_search))
        if url_search is not '':
            listing = []
            ID = []  # IMDB_ID or thetvdb ID
            cm = 0
            while True:
                if settings.time_noti > 0: settings.dialog.notification(settings.name_provider, 'Checking Online...',
                                                                        settings.icon, settings.time_noti)
                if len(lists) > 0:
                    reponse = browser.open(url_search + lists[cm])
                else:
                    reponse = browser.open(url_search)
                if reponse:
                    data = browser.content
                    if options[ret] == 'Movies Popular' or options[ret] == 'Movies Trending':
                        data = data[data.find('/movies/popular'):]
                    items = re.findall('data-type="movie" data-url="/movies/(.*?)"', data)
                    if len(items) > 0:  # there is movies
                        listing = [item[:-4].replace('-', ' ') + ' (' + item[-4:] + ')' for item in items]
                        subscription.integration(listing=listing, ID=ID, type_list='MOVIE', silence=True, message=options[ret],
                                                 folder=settings.movie_folder, name_provider=settings.name_provider)
                    if options[ret] == 'TV Popular' or options[ret] == 'TV Trending':
                        data = data[data.find('/shows/popular'):]
                    items = re.findall('data-type="show" data-url="/shows/(.*?)"', data)
                    if len(items) > 0:  # there is tv shows
                        listing = [item.replace('-', ' ') for item in items]
                        subscription.integration(listing=listing, ID=ID, type_list='SHOW', folder=settings.show_folder,
                                                 name_provider=settings.name_provider, silence=True, message=options[ret])
                else:
                    settings.log('[%s]>>>>>>>%s<<<<<<<' % (settings.name_provider_clean, browser.status))
                    settings.dialog.notification(settings.name_provider, browser.status, settings.icon, 1000)
                    break
                cm += 1
                if cm >= len(lists): break
    del settings
    del browser


if Addon().getSetting('service') == 'true':
    sleep(int(Addon().getSetting('delay_time')))  # get the delay to allow pulsar starts
    persistent = Addon().getSetting('persistent')
    name_provider = re.sub('.COLOR (.*?)]', '', Addon().getAddonInfo('name').replace('[/COLOR]', ''))
    every = 28800  # seconds
    previous_time = time()
    log("[%s] Update Service starting..." % name_provider)
    update_service()
    while (not abortRequested) and persistent == 'true':
        if time() >= previous_time + every:  # verification
            previous_time = time()
            update_service()
            log('[%s] Update List at %s' % (name_provider, asctime(localtime(previous_time))))
            log('[%s] Next Update in %s' % (name_provider, strftime("%H:%M:%S", gmtime(every))))
            update_service()
        sleep(500)
