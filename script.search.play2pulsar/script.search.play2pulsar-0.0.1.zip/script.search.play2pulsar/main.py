# coding: utf-8
import re
from urllib import quote_plus
import commontools
from xbmcgui import Dialog
from xbmc import executebuiltin

# this read the settings
settings = commontools.Settings()
# define the browser
browser = commontools.Browser()
# create the filters
filters = commontools.Filtering()


# using function from Steeve to add Provider's name and search torrent
def torrentz(query):
    filters.title = query
    query = quote_plus(query.rstrip())
    url_search = settings.query1 % query
    #provider.log.info(url_search)
    if browser.open(url_search):
        data = browser.content
        try:
            filters.information()  # print filters settings
            data = commontools.clean_html(data)
            data = data[data.find('peers'):].replace('<b>', '').replace('</b>', '').replace('class="pe">Pending',
                                                                                            'class="s">0 MB')  # short the result
            size = re.findall('class="s">(.*?)</span>', data)  # list the size
            seeds = re.findall('class="u">(.*?)</span>', data)  # list the seeds
            peers = re.findall('class="d">(.*?)</span>', data)  # list the seeds
            cont = 0
            results = []
            for cm, (infohash, name) in enumerate(re.findall('<dl><dt><a href="/(.*?)">(.*?)<', data)):
                torrent = 'magnet:?xt=urn:btih:%s' % infohash
                name = name.replace('-', ' ').title() + ' - ' + size[
                    cm]  # + ' - ' + settings.name_provider  # find name in the torrent
                if filters.verify(name, size[cm]):
                    results.append({"name": name, "uri": torrent, "info_hash": infohash,
                                    "size": commontools.size_int(size[cm]), "seeds": int(seeds[cm].replace(',', '')),
                                    "peers": int(peers[cm].replace(',', '')), "language": settings.language,
                                    "trackers": settings.trackers})  # return le torrent
                    cont += 1
                else:
                    print(filters.reason)
                if cont == settings.max_magnets:  # limit magnets
                    break
            print('>>>>>>' + str(cont) + ' torrents sent to Pulsar<<<<<<<')
            return results
        except:
            print('>>>>>>>ERROR parsing data<<<<<<<')
            #provider.notify(message='ERROR parsing data', header=None, time=5000, image=settings.icon)
    else:
        print('>>>>>>>%s<<<<<<<' % browser.status)
        #provider.notify(message=browser.status, header=None, time=5000, image=settings.icon)


dialog = Dialog()
query = dialog.input('Query:')
if query != '':
    results = torrentz(query)
    if results == [] or results is None:
        dialog.ok('Search2Pulsar', 'No results')
    else:
        list = [result['name'] for result in results]
        seeds = [' S:%s' % result['seeds'] for result in results]
        peers = [' P:%s' % result['peers'] for result in results]
        magnet = [result['uri'] for result in results]
        lists = [ item1 + item2 + item3 for (item1, item2, item3) in zip(list, seeds, peers)]
        list_rep = dialog.select('Choose File', lists + ['CANCEL'])
        if list_rep < len(list):
            executebuiltin("PlayMedia(plugin://plugin.video.pulsar/play?uri=%s)" % quote_plus(magnet[list_rep]))

del dialog
del settings
del browser
del filters